from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')

def signUp(request):
    return render(request, 'signUp.html')

def add_home(request):
    return render(request, 'add_home.html')

def buy_home(request):
    return render(request, 'buy_home.html')

def rent_home(request):
    return render(request, 'rent_home.html')

def about_us(request):
    return render(request, 'about_us.html')

def contact_us(request):
    return render(request, 'contact_us.html')

def reset_password(request):
    return render(request, 'reset_password.html')

def show_home(request):
    return render(request, 'show_home.html')

def page404(request):
    return render(request, 'page404.html')

def page500(request):
    return render(request, 'page500.html')
